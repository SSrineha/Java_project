package in.msitprogram.jntu.paypal;

import java.io.IOException;

import in.msitprogram.jntu.paypal.console.MainMenu;

/**
 * @author S.Srineha 18031j0087
 *
 */
public class PPSystem 
{

	public static void main(String[] args) throws Exception 
	{
		MainMenu.show();
	}

}
