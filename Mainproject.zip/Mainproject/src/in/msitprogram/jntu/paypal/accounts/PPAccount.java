package in.msitprogram.jntu.paypal.accounts;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

import in.msitprogram.jntu.paypal.utils.PPToolkit;

public class PPAccount implements Serializable
{
	/**
	 * 
	 */
	private Profile profile;
	private String email;
	private float accountBal;
	private boolean isActivated;
	private String activationCode;
	private ArrayList<Transaction> transactions;
	private String dob;
	private String p;
	private double amount;
	private double balance;
	int Result;
	public PPAccount(Profile profile) {
		// TODO Auto-generated constructor stub
		this.profile=profile;
	}
	public void setStatus(boolean status)
	{
		isActivated=status;
	}
    public boolean getStatus()
    {
    	return isActivated;
    }
	public String toString()
	{
		// implement this function to return a beautiful looking string
		// to display the summary of the account
		
		return null;
	}

	public void activate(String activationCode) 
	{
		
		// TODO Auto-generated method stub
		this.activationCode=activationCode;
		
	}
	public String getactivate()
	{
		return activationCode;
	}
	
	public void suspend() 
	{
		// TODO Auto-generated method stub
	}


	public boolean withdraw(float withdrawAmount) {
		
		return false;
	}


	public boolean addFunds(float creditAmount) 
	{
		
		return false;
	}
	
	public boolean sendMoney(float creditAmount) 
	{
		
		return false;
	}
	
	public boolean requestMoney(float creditAmount) 
	{
		
		return false;
	}
	
	public void setEmail(String email) {
		// TODO Auto-generated method stub
		this.email=email;
	}
	public String getEmail() {
		// TODO Auto-generated method stub
		return email;
	}
	public void setdob(String d)
	{
		dob=d;
	}
	public void getdob()
	{
		System.out.println(dob);
	}
	public void setpan(String pan)
	{
	p=pan;
	}
	public void getpan()
	{
		System.out.println(p);
	}
	public void setAmount(double a)
	{
		amount=a;
	}
	public double getAmount()
	{ 
		return amount;
	}
	
	
}
	
	

