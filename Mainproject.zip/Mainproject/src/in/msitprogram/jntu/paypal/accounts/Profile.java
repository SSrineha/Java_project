package in.msitprogram.jntu.paypal.accounts;

import java.io.Serializable;

public class Profile implements Serializable
{
	
	private String name;
	private String address;
	private String phone;
	     public void setName(String name)
	    {
		 this.name=name;
	    }
		 public void getName()
		 {
			 System.out.println();
		 }
		public void setAddress(String address)
		{
			this.address=address;
		}
		public void getAddress()
		{
			System.out.println(address);
		}
		
		public void setPhone(String phone)
		{
			this.phone=phone;
		}
		public void getPhone()
		{
			System.out.println(phone);
		}
			
	 }

