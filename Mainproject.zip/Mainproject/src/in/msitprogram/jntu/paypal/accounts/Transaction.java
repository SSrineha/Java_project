package in.msitprogram.jntu.paypal.accounts;

import java.util.Scanner;

public class Transaction
{
	String tTime;
	String tDate;
	PPAccount account;
	String narration;
	String reference;
	String status;
	float debit;
	float credit;
	public void show()
	{
		System.out.println("1.credit\n 2.Debit\n3.Balance\n");
		System.out.println("Enter Choice:");
		Scanner sc=new Scanner(System.in);
		int ch=sc.nextInt();
		switch(ch)
		{
			case 1:
				
		}
	}
	public String toString()
	{
		//return the description of the transaction 
		return null;
	}
	
}
