/**
 * 
 */
package in.msitprogram.jntu.paypal.console;

import java.io.IOException;
import java.util.Scanner;

import in.msitprogram.jntu.paypal.persistance.DataStore;

/**ss
 * @author s.srineha 18031j0087
 *
 */
public class MainMenu {
	
	public static void show() throws Exception{
		//show the welcome message with the main menu options
		
		//take the menu option as input from the console
		
		//take email address as input from the console
		
		//based on the given menu option instantiate the respective screens
	Scanner sc=new Scanner(System.in);
	System.out.println("1.sign up\n"+"2.signin\n"+"3.exit\n");
	System.out.println("enter Option:");
	int t=sc.nextInt();
	sc.nextLine();
	String email;
	switch(t)
	{
	case 1:
	  System.out.println("1.Sign up\n");
	  System.out.println("create your paypal email id:");
	  email=sc.nextLine();
	  if(DataStore.lookupAccount(email)!=null)
	  {
		  System.out.println("email id is existed");
		  MainMenu.show();
	  }
	  else
	  {
		  System.out.println("----Ready create a account----");
		  PPNewAccountScreen account=new PPNewAccountScreen(email);
		  account.show();
	  }
	   break;
	case 2:
		  System.out.println("2.Signin");
		  System.out.println("enter your email-id:");
		  email=sc.nextLine();
		  if(DataStore.lookupAccount(email)!=null)
		  {
			  PPAccountScreen screen=new PPAccountScreen(email);
			  screen.show();
		  }
		  else
		  {
			  System.out.println("invalid email address\n signup:");
			  MainMenu.show();  
		  }
		 
		  break;
	case 3:
		  System.out.println("3.exit");
		  break;
	default:System.out.println(" choose diplay options"); 
	}
	}

}
