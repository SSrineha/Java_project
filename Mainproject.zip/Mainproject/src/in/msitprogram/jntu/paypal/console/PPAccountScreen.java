package in.msitprogram.jntu.paypal.console;

import java.io.IOException;
import java.util.Scanner;

import in.msitprogram.jntu.paypal.accounts.PPAccount;
import in.msitprogram.jntu.paypal.persistance.DataStore;

public class PPAccountScreen {
	
	static PPAccount account;
	Scanner scan;
	 static String email;
	 static double creditbal;
	 static double debitbal;
	 static double balance;
	 static double sendMoney; 
	 
	 public PPAccountScreen(String email) throws Exception {
		scan = new Scanner(System.in);
		account = DataStore.lookupAccount(email);
		this.email=email;
	}

	public static void show() throws Exception {
		
		//check if account is active
		//if active// print the account summary
		// print menu and accept menu options
	   // for all the paypal account operations
		System.out.println(account.getStatus());
		int n=100;
		for(int i=0;i<n;i++)
		{
		if(account.getStatus())
		{       System.out.println("***---welcome to pesonal account--***");
				System.out.println("1.credit\n 2.Debit\n3.Balance\n4.SendMoney\n5.Exit");
				System.out.println("Enter Choice:");
				Scanner sc=new Scanner(System.in);
				int ch=sc.nextInt();
				switch(ch)
				{
					case 1:
						System.out.println("1.credit");
						System.out.println("Enter Amount to credit:");
						double c=sc.nextDouble();
						credit(c);
						break;
					case 2:
						System.out.println("2.Debit");
						System.out.println("Enter Amount to debit:");
						double d=sc.nextDouble();
						debit(d);
						break;
					case 3:
						System.out.println("3. Balance");
						System.out.println("Balance Amount is:"+account.getAmount());
						break;
					case 4:
						System.out.println("4. sendMoney");
						sendMoney();
						break;
					case 5:
						System.out.println("5.exit");
						MainMenu.show();
						break;
						default:System.out.println("enter your choice:");
					}
		}
		else
		{
			PPAccountActivationScreen.show(email);
		}
		
	}
	}
	public static void credit(double credit) throws Exception
	{
		balance=account.getAmount();
		creditbal=balance+credit;
		account.setAmount(creditbal);	
		System.out.println("credit amount:"+creditbal);
		DataStore.writeAccount(account);
	}
    public static void debit(double debit) throws Exception
    {
    	balance=account.getAmount();
    	debitbal=balance-debit;
    	account.setAmount(debitbal);
    	System.out.println("debited amount"+debitbal);
    	DataStore.writeAccount(account);
    }
	private void withdrawFunds() throws IOException {
		// implement the withdraw funds user interface here
		//use the account object as needed for withdraw funds
	}

	private void requestMoney() {
		// 	implement the request money user interface here
		
		//use the account object as needed for request money funds
	}

	private static void sendMoney() throws Exception {
		// implement the send money user interface here
		//use the account object as needed for send money funds
		System.out.println("enter email");
		Scanner sc=new Scanner(System.in);
		String mail=sc.nextLine();
		PPAccount account1=DataStore.lookupAccount(mail);
		if(account1!=null)
		{
			System.out.println("enter the amount to credit for sender");
			double c=sc.nextDouble();
			balance=account.getAmount();
	        if(balance>c)
		{
			double bal1=account1.getAmount();
			bal1=bal1+c;
			account1.setAmount(bal1);
			account.setAmount(balance-c);
			DataStore.writeAccount(account);
			DataStore.writeAccount(account1);
		}
		else
		{
			System.out.println("enter the amount is excess");
			System.out.println("available"+balance);
			
		}
	}
	}

	private void addFunds() throws IOException {
		// implement the add funds user interface here
		
		//use the account object as needed for add funds
	}

}