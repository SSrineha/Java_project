/**
 * 
 */
package in.msitprogram.jntu.paypal.utils;
import java.util.*;
/**
 * @author pg
 *
 */
public class PPToolkit {

	public static String generateActivationCode() 
	{
		// create instance of Random class 
        Random rand = new Random();
        System.out.println("Random number:");
        System.out.println("*******************");
  
        // Generate random integers in range  1to 6 
        int min = 10; 
        int max = 10000; 
        int Result=rand.nextInt(max-min)+1;
  
        // Print random integers 
        System.out.println(Result);
       
	    return String.valueOf(Result);
	}

	public static void sendActivationCode(String phone) 
	{
		
		
	}

}
